// src/app/product-list/product-list.component.ts
import { Component } from '@angular/core';
import { Product } from '../product';


@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css'],
})
export class ProductListComponent {
  products = [
    {
      name: 'Product 1',
      price: 100,
      description: 'Description for Product 1',
    },
    {
      name: 'Product 2',
      price: 200,
      description: 'Description for Product 2',
    },
    // Add more products as needed
  ];

  onNotify(product: Product) {
    window.alert(`You will be notified when ${product.name} goes on sale.`);
  }
  
}
