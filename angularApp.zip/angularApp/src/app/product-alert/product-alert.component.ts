// src/app/product-alert/product-alert.component.ts
import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-product-alert',
  templateUrl: './product-alert.component.html',
  styleUrls: ['./product-alert.component.css'],
})
export class ProductAlertComponent {
  @Input() product: any;
  @Output() notify = new EventEmitter();

  notifyMe() {
    this.notify.emit(this.product);
  }
}
